﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Window_Final_Act
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pnlRight_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pic_Click(object sender, EventArgs e)
        {

        }

        private void pnlLeft_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnSignUpTab_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void btnSignUp_Click(object sender, EventArgs e)
        {
            Form2 signup = new Form2();
            signup.Show();
            this.Hide();
        }

        private void lblSignUpMessage_Click(object sender, EventArgs e)
        {

        }
        private void lblSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();

            using (Form2 signup = new Form2())
            {
                signup.ShowDialog();
            }

            this.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {


        }

        private void label1_Click_1(object sender, EventArgs e)
        {


            {
                this.Hide();

                Form2 register = new Form2();
                register.ShowDialog();

                this.Show();
            }


        }
        private void lblSignup_Click(object sender, EventArgs e)

        {
            Form2 signup = new Form2();
            signup.Show();
            this.Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text;

            if (email == "" || password == "")
            {
                MessageBox.Show("Please enter your email and password.");
                return;
            }

            UserAccount account = null;

            foreach (UserAccount user in DataStorage.Users)
            {
                if (string.Equals(user.Email, email,
                    StringComparison.OrdinalIgnoreCase) &&
                    user.Password == password)
                {
                    account = user;
                    break;
                }
            }

            if (account != null)
            {
                MessageBox.Show("Login successful!");

                Form3 customerForm = new Form3();
                customerForm.Show();

                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid email or password.");
            }
        }

        private void btnSignUp_Click_1(object sender, EventArgs e)
        {
            Form2 signup = new Form2();
            signup.Show();
            this.Hide();
        }
    }
}
