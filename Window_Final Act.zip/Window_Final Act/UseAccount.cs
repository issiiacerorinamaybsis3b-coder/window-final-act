﻿using System.Collections.Generic;

namespace Window_Final_Act
{
    public class UserAccount
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Contact { get; set; }
        public string Password { get; set; }
    }
}