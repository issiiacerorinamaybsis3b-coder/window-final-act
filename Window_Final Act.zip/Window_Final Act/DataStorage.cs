﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Window_Final_Act
{
   class DataStorage
    {
        public static List<UserAccount> Users = new List<UserAccount>();

        public static List<Customer> Customers = new List<Customer>();
    }
}
