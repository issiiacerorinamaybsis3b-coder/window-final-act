﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Window_Final_Act
{
    public partial class Form3 : Form
    {
        Customer selectedCustomer = null;
        public Form3()
        {
            InitializeComponent();
            cmbGender.Items.Add("Male");
            cmbGender.Items.Add("Female");

            cmbGender.DropDownStyle = ComboBoxStyle.DropDownList;


            dgvCustomers.ReadOnly = true;
            dgvCustomers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCustomers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            btnAdd.Click += btnAdd_Click;
            btnClear.Click += btnClear_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnSearch.Click += btnSearch_Click;
            btnDelete.Click += btnDelete_Click;
            btnLogOut.Click += btnLogOut_Click;

            dgvCustomers.CellClick += DgvCustomers_CellClick;

            LoadCustomers();
        }

        private void LoadCustomers ()
        {
            dgvCustomers.DataSource = null;

            if (DataStorage.Customers.Count > 0)
            {
                dgvCustomers.DataSource = DataStorage.Customers.ToList();
            }
            else
            {
                dgvCustomers.DataSource = null;
            }

            selectedCustomer = null;

        }
        private void DgvCustomers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= dgvCustomers.Rows.Count)
            {
                return;
            }

            Customer customer = dgvCustomers.Rows[e.RowIndex].DataBoundItem as Customer;

            if (customer != null)
            {
                selectedCustomer = customer;

                txtFirstName.Text = customer.FirstName;
                txtMiddle.Text = customer.MiddleName;
                txtLastName.Text = customer.LastName;
                cmbGender.SelectedItem = customer.Gender;

                if (DateTime.TryParse(customer.Birthday, out DateTime birthday))
                {
                    dtpBirthday.Value = birthday;
                }

                txtContact.Text = customer.Contact;
                txtEmail.Text = customer.Email;
                txtAddress.Text = customer.Address;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string search = txtSearchInput.Text.Trim().ToLower();

            var results = DataStorage.Customers.Where(c =>
                c.FirstName.ToLower().Contains(search) ||
                c.LastName.ToLower().Contains(search) ||
                c.Email.ToLower().Contains(search)
            ).ToList();

            dgvCustomers.DataSource = null;
            dgvCustomers.DataSource = results;

            if (results.Count == 0)
            {
                MessageBox.Show("Customer not found.");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtFirstName.Text == "" ||
               txtLastName.Text == "" ||
               cmbGender.Text == "" ||
               txtContact.Text == "" ||
               txtEmail.Text == "")
            {
                MessageBox.Show("Please complete the required fields.");
                return;
            }

            Customer customer = new Customer()
            {
                FirstName = txtFirstName.Text,
                MiddleName = txtMiddle.Text,
                LastName = txtLastName.Text,
                Gender = cmbGender.Text,
                Birthday = dtpBirthday.Value.ToShortDateString(),
                Contact = txtContact.Text,
                Email = txtEmail.Text,
                Address = txtAddress.Text
            };

            DataStorage.Customers.Add(customer);

            LoadCustomers();
            ClearFields();

            MessageBox.Show("Customer added successfully!");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedCustomer == null)
            {
                MessageBox.Show("Please select a customer first.");
                return;
            }

            if (cmbGender.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a gender.");
                return;
            }

            selectedCustomer.FirstName = txtFirstName.Text;
            selectedCustomer.MiddleName = txtMiddle.Text;
            selectedCustomer.LastName = txtLastName.Text;
            selectedCustomer.Gender = cmbGender.SelectedItem.ToString();
            selectedCustomer.Birthday = dtpBirthday.Value.ToShortDateString();
            selectedCustomer.Contact = txtContact.Text;
            selectedCustomer.Email = txtEmail.Text;
            selectedCustomer.Address = txtAddress.Text;

            LoadCustomers();
            ClearFields();

            MessageBox.Show("Customer updated successfully!");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadCustomers();
        }

        private void ClearFields()
        {
            txtFirstName.Clear();
            txtMiddle.Clear();
            txtLastName.Clear();
            cmbGender.SelectedIndex = -1;
            dtpBirthday.Value = DateTime.Today;
            txtContact.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            txtSearchInput.Clear();

            selectedCustomer = null;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedCustomer == null)
            {
                MessageBox.Show("Please select a customer first.");
                return;
            }

            DialogResult result = MessageBox.Show(
                "Are you sure you want to delete this customer?",
                "Delete Customer",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                DataStorage.Customers.Remove(selectedCustomer);

                LoadCustomers();
                ClearFields();

                MessageBox.Show("Customer deleted successfully!");
            }
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
              "Are you sure you want to logout?",
              "Logout",
              MessageBoxButtons.YesNo,
              MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Form1 loginForm = Application.OpenForms["Form1"] as Form1;

                if (loginForm != null)
                {
                    loginForm.Show();
                }

                this.Close();
            }
        }
    }
}
