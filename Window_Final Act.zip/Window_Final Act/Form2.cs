﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Window_Final_Act
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void pnlSignUpContent_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            if (txtFullName.Text == "" ||
            txtEmail.Text == "" ||
            txtContact.Text == "" ||
            txtPassword.Text == "" ||
            txtConfirmPassword.Text == "")
            {
                MessageBox.Show("Please complete all fields.");
            }
            else if (txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Password does not match.");
            }
            else if (!chkTerms.Checked)
            {
                MessageBox.Show("Please agree to the Terms and Conditions.");
            }
            else
            {
                UserAccount user = new UserAccount();

                user.Name = txtFullName.Text;
                user.Email = txtEmail.Text.Trim();
                user.Contact = txtContact.Text;
                user.Password = txtPassword.Text;

                DataStorage.Users.Add(user);

                MessageBox.Show("Account Created Successfully!");

                Form1 login = new Form1();
                login.Show();
                this.Hide(); if (txtFullName.Text == "" ||
                txtEmail.Text == "" ||
                txtContact.Text == "" ||
                txtPassword.Text == "" ||
                txtConfirmPassword.Text == "")
                {
                    MessageBox.Show("Please complete all fields.");
                    return;
                }

                if (txtPassword.Text != txtConfirmPassword.Text)
                {
                    MessageBox.Show("Passwords do not match!");
                    return;
                }

                if (!chkTerms.Checked)
                {
                    MessageBox.Show("Please accept the Terms and Conditions.");
                    return;
                }


                foreach (UserAccount users in DataStorage.Users)
                {
                    if (string.Equals(users.Email, txtEmail.Text.Trim(),
                        StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Email is already registered!");
                        return;
                    }
                }

                UserAccount newUser = new UserAccount()
                {
                    Name = txtFullName.Text,
                    Email = txtEmail.Text.Trim(),
                    Contact = txtContact.Text,
                    Password = txtPassword.Text
                };

           
                DataStorage.Users.Add(newUser);

                MessageBox.Show("Account created successfully! Please login.");

          
                Form1 loginForm = Application.OpenForms["Form1"] as Form1;

                if (loginForm != null)
                {
                    loginForm.Show();
                }

                this.Close();
            
        }
        }

        private void lblFullName_Click(object sender, EventArgs e)
        {

        }
        private void lblLogin_Click(object sender, EventArgs e)
        {
           
         
        }

    }

}

